# நம்ம திருப்பூர் — Android Apps

This repository contains two Android apps:
- `user-app` — நம்ம திருப்பூர்
- `admin-app` — நம்ம திருப்பூர் Admin

## Current payment flow
- Generic local advertisement: ₹5
- Valid for 1 day
- UPI only
- User sees QR + UPI ID, pays externally, then submits the ad
- Admin verifies and approves
- Approved ads expire after 1 day in the production data layer
- Admin can change UPI ID and QR Code from Payment Settings

## Firebase note
The supplied Firebase configuration belongs to the existing Firebase Android app package `com.namma.perumanallur`. The user app intentionally keeps that package ID for compatibility with the supplied `google-services.json`. The Admin app initializes Firebase directly from the same project configuration so this starter can be opened/build without a second `google-services.json`. For a production release, register the final Admin Android app in Firebase and replace the direct options with its official app registration.

## Build on GitHub
1. Push this repository to GitHub.
2. GitHub Actions workflow in `.github/workflows/android.yml` builds both debug APKs.
3. `google-services.json` is included only because it was supplied for this project. Keep repository visibility and Firebase rules appropriate for your deployment.

## Firestore
Publish `firestore.rules` to the Firebase project. The Admin email used by the rules is `hariharan842719@gmail.com`.
