package com.namma.perumanallur.admin

import android.os.Bundle
import android.util.Base64
import android.graphics.BitmapFactory
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.activity.compose.rememberLauncherForActivityResult
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.io.ByteArrayOutputStream

private val Navy=Color(0xFF123B7A); private val Sky=Color(0xFF19A8D8); private val Bg=Color(0xFFF7F9FC)
class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);val o=FirebaseOptions.Builder().setProjectId("namma-perumanallur").setApplicationId("1:82242597281:android:7b8095714dc7b2beb95be0").setApiKey("AIzaSyApSpIoqBtp82F91RJ9-XkJ-9D3wZogCDg").setStorageBucket("namma-perumanallur.firebasestorage.app").build();if(FirebaseApp.getApps(this).isEmpty())FirebaseApp.initializeApp(this,o);setContent{AdminApp()}}}
@Composable fun AdminApp(){var login by remember{mutableStateOf(FirebaseAuth.getInstance().currentUser!=null)};if(!login)AdminLogin{login=true}else Dashboard()}
@Composable fun AdminLogin(done:()->Unit){var e by remember{mutableStateOf("")};var p by remember{mutableStateOf("")};var m by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.Center){Text("நம்ம திருப்பூர் Admin",fontSize=30.sp,fontWeight=FontWeight.Bold,color=Navy);Spacer(Modifier.height(20.dp));OutlinedTextField(e,{e=it},label={Text("Admin Email")},modifier=Modifier.fillMaxWidth());OutlinedTextField(p,{p=it},label={Text("Password")},modifier=Modifier.fillMaxWidth());Button(onClick={FirebaseAuth.getInstance().signInWithEmailAndPassword(e,p).addOnSuccessListener{done()}.addOnFailureListener{m="Login failed"}},modifier=Modifier.fillMaxWidth().padding(top=16.dp)){Text("Admin Login")};if(m.isNotEmpty())Text(m,color=MaterialTheme.colorScheme.error)}}
@Composable fun Dashboard(){var screen by remember{mutableStateOf("dash")};when(screen){"dash"->Column(Modifier.fillMaxSize().padding(16.dp)){Text("Admin Dashboard",fontSize=30.sp,fontWeight=FontWeight.Bold,color=Navy);Spacer(Modifier.height(20.dp));listOf("Pending Users","Shop Applications","Jobs","Rental Vehicles","Government Offices","Emergency Help","Events","Ads","Payments").forEach{Text("• $it",fontSize=18.sp,modifier=Modifier.padding(8.dp))};Button(onClick={screen="payment"},modifier=Modifier.fillMaxWidth().padding(top=16.dp)){Text("💳 Payment / UPI Settings")}};"payment"->PaymentSettings{screen="dash"}}}
@Composable fun PaymentSettings(back:()->Unit){val ctx=LocalContext.current;var upi by remember{mutableStateOf("8220842719@ptyes")};var qr by remember{mutableStateOf<String?>(null)};LaunchedEffect(Unit){FirebaseFirestore.getInstance().collection("appConfig").document("payment").get().addOnSuccessListener{d->upi=d.getString("upiId")?:upi;qr=d.getString("qrBase64")}};val picker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){uri->if(uri!=null){val ins=ctx.contentResolver.openInputStream(uri);val bmp=BitmapFactory.decodeStream(ins);val out=ByteArrayOutputStream();bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG,80,out);qr=Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP)}};Column(Modifier.fillMaxSize().padding(16.dp)){Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick=back){Icon(Icons.Default.ArrowBack,null)};Text("Payment Settings",fontSize=24.sp,fontWeight=FontWeight.Bold,color=Navy)};OutlinedTextField(upi,{upi=it},label={Text("UPI ID")},modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(16.dp));if(qr!=null){val bytes=Base64.decode(qr,Base64.DEFAULT);val bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.size);Image(bmp.asImageBitmap(),"QR",Modifier.size(260.dp).align(Alignment.CenterHorizontally))};Button(onClick={picker.launch("image/*")},modifier=Modifier.fillMaxWidth().padding(top=12.dp)){Text("🖼️ QR Code மாற்று")};Button(onClick={FirebaseFirestore.getInstance().collection("appConfig").document("payment").set(mapOf("upiId" to upi,"qrBase64" to qr,"updatedAt" to System.currentTimeMillis()))},modifier=Modifier.fillMaxWidth().padding(top=12.dp)){Text("Save / Update")};Text("இந்த QR Code-ஐ User App-ன் ₹5 payment screen பயன்படுத்தும்.",color=Color.Gray,modifier=Modifier.padding(top=12.dp))}}
